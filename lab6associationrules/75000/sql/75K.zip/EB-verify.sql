---  EXTENDED BAKERY dataset
--- tuple counts
--- Alex Dekhtyar
 
 
--- Goods table
SELECT COUNT(*) as "Number of Goods"
FROM Goods;
 
--- Location table
SELECT COUNT(*) as "Number of Locations"
FROM Location;
 
 
--- Employee table
SELECT COUNT(*) as "Number of Employees"
FROM Employee;
 
--- Receipts table
SELECT COUNT(*) as "Number of Receipts "
FROM Receipts;
 
 
--- Items table
SELECT COUNT(*) as "Number of Items"
FROM Items;
 
 
-- 
