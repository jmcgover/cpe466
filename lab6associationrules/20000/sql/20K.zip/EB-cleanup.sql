remark Jacob Verburg
remark jverburg@calpoly.edu
drop table goods cascade constraints;
drop table location cascade constraints;
drop table employee cascade constraints;
drop table receipts cascade constraints;
drop table items cascade constraints;
